
package assignment20;

import java.util.Random;
import java.util.Scanner;


public class Assignment20 {

    
    public static void main(String[] args) {
      
        Random randomobj = new Random();
        Scanner keybord = new Scanner(System.in);
        int i;
        int askNumber;
        int searchNumber;
        int location=-1;
        int number = 0;
        
        
        System.out.println("How many lines? ");
        askNumber = keybord.nextInt();
        int[] array = new int[askNumber]; 
        
        System.out.println(""); 
        
        for (i=0;i<askNumber;i++)
        {
            number=randomobj.nextInt(800);
            array[i] = number;
            System.out.println(number);
                       
        }
        System.out.println("");
        
        System.out.println("Which number to search? ");
        searchNumber = keybord.nextInt();
        System.out.println("");
        
        for (i=0;i<askNumber;i++){
            
            if(searchNumber == array[i])
            {
                location = i+1;
            }
        }
         if (location==-1)
         {
             System.out.println("element not found");
         }
         else
         {
            System.out.println("element found at index: " + location);
         }
         System.out.println("");
    System.out.println("End of this assignment");
}    
}
  
   

    

