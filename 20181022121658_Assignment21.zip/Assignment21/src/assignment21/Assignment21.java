
package assignment21;

import java.util.Random;
import java.util.Scanner;


public class Assignment21 {

    public static void main(String[] args) {
        
        int askNumber;
        int number;
        
        Random randomobj = new Random();
        Scanner keybord = new Scanner(System.in);
        
        System.out.println("*****************************");
        System.out.println("Welcome to the Guessing GAme");
        System.out.println("*****************************");
        
        System.out.println("");
        
        
        do{
            System.out.println("Enter a number from 1 to 10: ");
            askNumber = keybord.nextInt();
            number=randomobj.nextInt(10);
           }while(number!=askNumber);
        
            if(askNumber==number)
            {
                System.out.println("you won! The number was " + number);
            }
           
        System.out.println("It took you " +askNumber +" guess to win");
    }
    
}
