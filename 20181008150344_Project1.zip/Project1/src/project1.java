	import java.util.Scanner;
	
	import com.sun.xml.internal.ws.util.StringUtils;
	
	public class project1 {
		
		static String[] nameList = new String[10];
		static String askContinue;
		public static void main(String[] args) {
				
			nameList[0] = "Jonathan";
			nameList[1] = "Roxanne";
			nameList[2] = "Jasmine";
			nameList[3] = "Sophinnne";
	
			askContinue = new String();
			Scanner keyboard = new Scanner(System.in);
			//askContinue = keyboard.nextLine();
			
			int i;
			
			//Main loop
			
			
				for (i=0; i<10; i++) {
					do {
					menuPrint(nameList);
					}while(askContinue.equals(keyboard.nextLine()));
	            }
			 
			
		}
		
		public static void menuPrint(String[] nameList) {
			
			//print main menu
			System.out.println("MAIN MENU");
			System.out.println("STUDENT ID: 1794882");
			System.out.println("STUDENT NAME: MADHURI PATEL");
			System.out.println("");
			System.out.println("1. Display the list");
			System.out.println("2. Insert an element");
			System.out.println("3. Swap two element");
			System.out.println("4. Quit");
			
			System.out.println("Your choice?");
			Scanner keyboard = new Scanner(System.in);
			int indexAsk;
			indexAsk = keyboard.nextInt();
			
				if (indexAsk < 1 || indexAsk > 4) {
	
			        System.out.println("Please enter valid number");
			        indexAsk = keyboard.nextInt();
					
			    }
	
			    else if(indexAsk == 1) {
			    	optionDisplay(nameList);
			    }
			    else if(indexAsk == 2) {
			    	optionInsert(nameList);
			    }
			    else if(indexAsk == 3) {
			    	optionSwap(nameList);
			    }
			    else {
			    	System.out.println("End of execution!....");
			    	System.exit(1);		    	
			    }
		}
		
		public static void vectorPrint(String[] nameList) {
			
			//Print array
			
			 for (int i=0; i<10; i++) {
		            System.out.print(i+1 + ". ");
		            if(nameList[i] == null) {
		            	nameList[i] = "";
		            	 System.out.println(nameList[i]);
		            }else {
		            	 System.out.println(nameList[i]);
		            }
		           
		        }
		}
		
		public static void optionDisplay(String[] nameList) {
			// call vector
			
			
			vectorPrint(nameList);
			System.out.println("Press ENTER to continue");
			Scanner keyboard = new Scanner(System.in);
			String askContinue;
		//	askContinue = keyboard.nextLine();
			
		}
		
		public static void optionInsert(String[] nameList) {
			
			//Insert element
			Scanner keyboard = new Scanner(System.in);
			int indexAsk;
			int i;
			String askContinue = new String();
			String nameToInsert = new String();
			
			// dispy array of name list
			vectorPrint(nameList);
			
			// Ask the user where he wants to insert
	        System.out.println("Where do you want to insert?");
	        indexAsk = keyboard.nextInt();
	        keyboard.nextLine();
	         
	        // Ask a name to the user
	        System.out.println("Please enter name: ");
	        nameToInsert = keyboard.nextLine();
	        
	        // Move all elements down before we can insert it
	        // at position 0
	        for (i=9; i>(indexAsk-1); i--) {
	        	nameList[i] = nameList[i-1];
	         }
	         
	         // Insert the name that was input by the user
	         // in the first element (0)
	        nameList[indexAsk-1] = nameToInsert;
	         
	        System.out.println("Press ENTER to continue");
	  //      askContinue = keyboard.nextLine();
	        
			
		}
		
		public static void optionSwap(String[] nameList) {
			
			// dispy array of name list
			vectorPrint(nameList);
					
			//swap element
			int num1;
			int num2;
			String temp;
			String askContinue = new String();
			Scanner keyboard = new Scanner(System.in);
			System.out.println("From element");
			num1=keyboard.nextInt();
		    System.out.println("To element");
		    num2=keyboard.nextInt();
		    temp=nameList[num1-1];
		    nameList[num1-1]=nameList[num2-1];
		    nameList[num2-1]=temp;
		    
		    
		    for(int i=0;i<10;i++)
		    {
		    	System.out.println((i+1)+"."+nameList[i]);
		    }
		    
		    System.out.println("Press ENTER to continue");
	        askContinue = keyboard.nextLine();
			
			
		}
		
		
	
	}
